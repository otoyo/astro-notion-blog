export const snakeToKebab = (s: string) => s.replaceAll('_', '-')
